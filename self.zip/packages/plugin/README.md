https://github.com/agentcooper/parcel-plugin-static-zip
