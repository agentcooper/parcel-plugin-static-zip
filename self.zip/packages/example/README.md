Example Parcel project for [`parcel-plugin-static-zip`](https://github.com/agentcooper/parcel-plugin-static-zip).

The code renders minimal UI to browse the project itself in the browser.
